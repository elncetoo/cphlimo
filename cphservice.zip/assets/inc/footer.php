<link rel="stylesheet" href="assets/css/footer.css">
 
<div class="footer">
 </br>
<p>Exam Project <a style="padding-bottom:2%; text-decoration:none; color: #6b6b6b;" href="www.cphbusiness.dk">CPH Business</a> &copy; MIL16</p>
</br></br>
</div>
</br>
</body>
</html>

